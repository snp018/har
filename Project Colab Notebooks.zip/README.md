# har


HumanActRecog.ipynb
	- This is a main emotion detection model notebook which cab be run in colab.
	- Dataset included can be downloaded from https://github.com/snp018/har/tree/master/har

objectDetection.ipynb
	- This is a model which can be used to detect weapon
	- Dataset included can be downloaded from https://github.com/snp018/har/tree/master/wdetection/images
	
HumanActRecog96x96.ipynb
	- This id modified version of emotion detection model (HumanActRecog) which is tweaked to use image shape of 96X96
	
Celebrity_input_shape175x175.ipynb
	- This is new experiment we did on image shape of size 175x175 and new model is written to detect celebirty faces.


